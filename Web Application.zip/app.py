from flask import Flask, render_template, request
import cv2
import numpy as np
from load import*
import os


def decode(f):
    labels = {0: 'malignant', 1: 'benign', 2: 'normal'}
    return labels[f]
    
imageSize = 180
app = Flask(__name__)

@app.route("/")
def upload_file():
   return render_template('index.html')

model= init()

@app.route('/predict', methods=['GET','POST'])
def predict():
   if request.method == 'POST':
      if request.files['file']:
         f = request.files['file']
         fileName = str(f.filename)
         f.save(fileName)

         image = cv2.imread(fileName)
         image = cv2.resize(image, (imageSize, imageSize))
         image_gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
         image_blur = cv2.GaussianBlur(image_gray, (7, 7), 0)
         _, thresh_image = cv2.threshold(image_blur, 100, 255, cv2.THRESH_BINARY)
         contours, hierarchy = cv2.findContours(thresh_image, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
         image_contour = cv2.drawContours(image_gray, contours, -1, (0, 255, 0), 2)

         uploaded_image = np.array(image_contour)
         uploaded_image = uploaded_image /255
         
         out = model.predict(uploaded_image)
         predicted = np.argmax(out)
         os.remove(fileName)
         y_predict =  decode(predicted)
         
         if y_predict == 'normal':
            return render_template("normal.html")
         elif y_predict == 'malignant':
            return render_template("malignant.html")
         elif y_predict == 'benign':
            return render_template("benign.html")

      else: return "File not selected" 
      

if __name__ == '__main__':
   app.run(debug = True)    